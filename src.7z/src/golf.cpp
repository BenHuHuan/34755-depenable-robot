#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include "golf.h"

cv::Mat GetHSV(const cv::Mat& image) {
    int hmin = 5, hmax = 30;
    int smin = 30, smax = 255;
    int vmin = 210, vmax = 255;
    cv::Mat hsv;
    cv::cvtColor(image, hsv, cv::COLOR_BGR2HSV);
    cv::Mat binary;
    cv::inRange(hsv, cv::Scalar(hmin, smin, vmin), cv::Scalar(hmax, smax, vmax), binary);
    return binary;
}

std::vector<cv::Point2f> ImageProcessing(const cv::Mat& img) {
    cv::Mat binary = GetHSV(img);
    cv::Mat blur;
    cv::GaussianBlur(binary, blur, cv::Size(9, 9), 0);
    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(9, 9));
    cv::Mat Open;
    cv::morphologyEx(blur, Open, cv::MORPH_OPEN, kernel);
    cv::Mat Close;
    cv::morphologyEx(Open, Close, cv::MORPH_CLOSE, kernel);

    std::vector<cv::Vec3f> circles;
    cv::HoughCircles(Close, circles, cv::HOUGH_GRADIENT, 2, 30, 30, 60, 15, 80);

    cv::Mat camera_matrix = (cv::Mat_<double>(3,3) << 1076.5, 0.0, 589.1, 0.0, 1071.6, 453.8, 0.0, 0.0, 1.0);
    cv::Mat distortion_coeffs = (cv::Mat_<double>(1,5) << -0.398751, 0.040313, -0.0105357, 0.00755715, 0.153358);
    double f = (camera_matrix.at<double>(0,0) + camera_matrix.at<double>(1,1)) / 2;
    double d_real = 42.67;

    std::vector<cv::Point2f> positions;
    for (size_t i = 0; i < circles.size(); i++) {
        cv::Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
        int radius = cvRound(circles[i][2]);
        cv::circle(img, center, radius, cv::Scalar(255, 0, 255), 5);
        double d_pixel = 2 * radius;

        std::vector<cv::Point2f> pt_dist = {{static_cast<float>(center.x), static_cast<float>(center.y)}};
        std::vector<cv::Point2f> pt_undist;
        cv::undistortPoints(pt_dist, pt_undist, camera_matrix, distortion_coeffs, cv::noArray(), camera_matrix);

        double scale = d_real / d_pixel;
        double x = (pt_undist[0].x - camera_matrix.at<double>(0,2)) * scale;
        double z = f * scale;
        positions.push_back(cv::Point2f(x, z));
    }

    // Optional: Display the processed image
    // cv::imshow("Processed Image", img);
    // cv::waitKey(0);
   
        return positions;
    
    
}

// int main() {
//     cv::VideoCapture cap(0); // Open the default camera
//     if (!cap.isOpened()) {
//         std::cerr << "Camera is not ready" << std::endl;
//         return -1;
//     }

//     cv::Mat frame;
//     bool ret = cap.read(frame);
//     if (!ret) {
//         std::cerr << "Failed to read frame" << std::endl;
//         return -1;
//     }
    
//     std::vector<cv::Point2f> positions = ImageProcessing(frame); // 处理图像
//     if (!positions.empty()) {
//         // 如果检测到至少一个圆形对象，则打印所有检测到的位置
//         for (const auto& pos : positions) {
//             std::cout << "Position: x = " << pos.x << ", z = " << pos.y << std::endl;
//         }
//         return 0; // 正常结束
//     } else {
//         std::cout << "No golf balls detected." << std::endl;
//         return -1; // 返回-1表示没有检测到高尔夫球
//     }
// }