#include <opencv2/opencv.hpp> 
#include <opencv2/core.hpp> 
#include <opencv2/imgproc.hpp> 
#include <opencv2/highgui.hpp> 
#include <opencv2/videoio.hpp> 
#include <iostream> 
#include <vector> 


#include <opencv2/core/types.hpp>
cv::Mat GetHSV(const cv::Mat& image);
std::vector<cv::Point2f> ImageProcessing(const cv::Mat& img);
